char dat[9];           // Bufer za primanje/slanje podataka/poruka
char i,j;              // Za kasnije koriscenje u petljama

sbit  rs485_rxtx_pin at RC2_bit;              // Primopredajni pin
sbit  rs485_rxtx_pin_direction at TRISC2_bit; // Smer primopredajnog pin-a

void interrupt() {         // Rutina prekida (interrupt-a)
 RS485Slave_Receive(dat);  // Mikrokontroler (slave) prima poruku...
}                          // ...preko RS485 modula

void main() {
  ADCON1 = 0x0F;           // Svi pinovi podeseni kao digitalni
  CMCON  = 0x07;           // Komparatori ugaseni

  PORTB = 0;               // Portovi B i D postavljani na nultu vrednost
  PORTD = 0;
  TRISB = 0;               // Portovi B i D postavljani kao izlazni
  TRISD = 0;

  UART1_Init(9600);        // Pokretanje UART1 modula
  Delay_ms(100);           // Vreme da se UART1 stabilizuje
  RS485Slave_Init(160);    // Postavljanje mikrokontrolera za slave, sa...
                           // ...adresom 160
  dat[4] = 0;              // Postavljanje flaga za prijem poruka
  dat[5] = 0;              // Postavljanje flag-a greske

  RCIE_bit = 1;            // Omogucen prekid prilikom UART1 prijema
  TXIE_bit = 0;            // Onemogucen prekid prilikom UART1 slanja
  PEIE_bit = 1;            // Omoguceni periferijski prekidi
  GIE_bit = 1;             // Omoguceni svi prekidi

  while (1) {
    if (dat[5])  {         // Ako se detektuje greska, podesi...
      PORTD = 0xAA;        // ...vrednost 0xAA na PORTD
      dat[5] = 0;          // Ocisti flag greske
    }
    if (dat[4]) {          // Prilikom zavrsenog prijema validne poruke...
      dat[4] = 0;          // ...data[4] je podesen na vrednost 255...
      j = dat[3];          // ...pa ga moramo takodje ocistiti
      for (i = 1; i <= dat[3];i++){  // Prikazuje podatak/poruku na PORTB
        PORTB = dat[i-1];
      }
      dat[0] = dat[0]+1;       // Inkrementuje primljeni podatak
      Delay_ms(100);           // Zbog sigurnosti da se podatak sredio
      RS485Slave_Send(dat,1);  // Salje podatak nazad master uredjaju
    }
  }
}