char dat[10];          // Bufer za primanje/slanje podataka/poruka
char i,j;              // Za kasnije koriscenje u petljama

sbit  rs485_rxtx_pin  at RC2_bit;               // Primopredajni pin
sbit  rs485_rxtx_pin_direction at TRISC2_bit;   // Smer primopredajnog pin-a

void interrupt() {             // rutina prekida (interrupt-a)
  RS485Master_Receive(dat);    // Mikrokontroler (master) prima poruku...
}                              // ...preko RS485 modula

void main(){
  long cnt = 0;                // Brojac koji se kasnije koristi

  ADCON1 = 0x0F;               // Svi pinovi podeseni kao digitalni
  CMCON  = 0x07;               // Komparatori ugaseni

  PORTB  = 0;                  // Portovi B i D postavljani na nultu vrednost
  PORTD  = 0;
  TRISB  = 0;                  // Portovi B i D postavljani kao izlazni
  TRISD  = 0;


  UART1_Init(9600);            // Pokretanje UART1 modula
  Delay_ms(100);               // Vreme da se UART1 stabilizuje

  RS485Master_Init();          // Postavljanje mikrokontrolera za master-a
  dat[0] = 0xAA;               // Postavljanje inicijalnih...
  dat[1] = 0xF0;
  dat[2] = 0x0F;
  dat[4] = 0;
  dat[5] = 0;
  dat[6] = 0;                  // ...vrednosti poruka

  RS485Master_Send(dat,1,160);   // Mikrokontroler (master) salje poruku...
                                 // ...slave uredjaju preko RS485 modula

  RCIE_bit = 1;                  // Omogucen prekid prilikom UART1 prijema
  TXIE_bit = 0;                  // Onemogucen prekid prilikom UART1 slanja
  PEIE_bit = 1;                  // Omoguceni periferijski prekidi
  GIE_bit = 1;                   // Omoguceni svi prekidi

  while (1){                     // Pocetak while petlje
                                 // Prilikom zavrsenog prijema validne poruke...
                                 // ...data[4] je podesen na vrednost 255
    cnt++;                       // Brojac se inkrementuje
    if (dat[5])  {               // Ako se desi neka greska, pokazuje se...
      PORTD = 0xAA;              // ...tako sto se PORTD postavi na 0xAA
    }
    if (dat[4]) {                // Ako je poruka uspesno primljena
      cnt = 0;                   // Brojac se postavlja na nulu
      dat[4] = 0;                // Cisti se flag za prijem validne poruke
      j = dat[3];
      for (i = 1; i <= dat[3]; i++) {  // Prikazuje podatak/poruku na PORTB
        PORTB = dat[i-1];
      }
      dat[0] = dat[0]+1;               // Inkrementuje primljeni podatak
      Delay_ms(100);                   // Zbog sigurnosti da se podatak sredio
      RS485Master_Send(dat,1,160);     // Salje podatak nazad slave uredjaju

    }
   if (cnt > 100000) {                 // Ako brojac predje odredjenu vrednost
      PORTD ++;                        // Vrednost PORT-a D se inkrementuje
      cnt = 0;                         // Brojac se vraca na nulu
      RS485Master_Send(dat,1,160);     // Master pokusava ponovno slanje
      if (PORTD > 10)                  // Ako slanje ne uspe iz 10 pokusaja
        RS485Master_Send(dat,1,50);    //  Master salje poruku na broadcast...
     }                                 // ...adresi, tj. salje svim slave...
  }                                    // ...uredjajima koji se nalaze na...
 }                                      // ...komunikacionom vodu